﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mod1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Math();   //can only be called if static

            //if  Math() is NOT static, must first create program object
            //Program myProgram = new Program();
            //myProgram.Math();
            //Program mySecondProgram = new Program();


            //convert();
            //UsingSB();
            //usingIFs();
            //Loops();
            //arrays();
            ForOrForeach();
        }

        #region maths
        public static void Math()
        //public void Math()
        {
            string name = "tom";
            int numb1 = 5;
            int numb2 = 5;
            //Console myconsole = new Console();
            StringBuilder mySB = new StringBuilder();
            mySB.Append("Hello");

            Console.WriteLine(numb1++);  //output = 
            Console.WriteLine(++numb2);  //output = 

            Console.WriteLine(numb1);   //
            Console.WriteLine(numb2);


            numb1 = 7;
            numb2 = 3;
            Console.WriteLine(numb1 / numb2);
            Console.WriteLine("The remainder is ... {0}", numb1 % numb2);

            //int case = 5;     //case is a reserved word
        }


        //as many methods as i want
        #endregion

        #region ???
        public static void convert()
        {
            string input = "1234y5";

            int myNumb = Convert.ToInt32(input) - 5;
            Console.WriteLine(myNumb);

            //Console.WriteLine(Convert.ToInt32(input));
        }

        public static void UsingSB()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Hello");
            sb.Append(" World");
            Console.WriteLine(sb);

            Program p = new Program();
            Console.WriteLine(p);
        }
        #endregion

        #region program flow

        public  static void usingIFs()
        {
            int input = 400;
            int cashInAccount = 350;

            if(cashInAccount >= input)
            {
                Console.WriteLine("here is ${0}", input);
            }
            else
            {
                Console.WriteLine("You dont have that much in your account");
            }

            int a = 4;
            int b = 5;
            int c = -476;

            if(a > b)
            {
                Console.WriteLine("A");
            }
            if (b > c)
            {
                Console.WriteLine("B");
            }
            if (c > a)
            {
                Console.WriteLine("C");
            }


            //////////////////////

            int currentGrade = 79;
            int averageGrade = 90;

            if(currentGrade > 100)
            {
                Console.WriteLine("HOW!?!?!?!?");
            }else if(currentGrade < 60)
            {
                Console.WriteLine("Fail");
            }else if (currentGrade < averageGrade)
            {
                Console.WriteLine("Below Avg");
            }
            else //Catches everything that gets to this point
            {

            }


            //case statements

            char commandInput = 'Y';

            switch (commandInput)
            {
                case 'Y':
                case 'y':
                    Console.WriteLine("You selected option 'Yes'");
                    break;
                case 'N':
                case 'n':
                    Console.WriteLine("You selected option 'No'");
                    break;
                case '1':
                    Console.WriteLine("You selected option '1'");
                    break;
                //more options
                
            }

            if (commandInput == 'Y' || commandInput == 'y')
            {
                Console.WriteLine("You selected option 'Yes'");
            }
            else if(commandInput == 'N' || commandInput == 'n')
            {
                Console.WriteLine("You selected option 'No'");
            }else if(commandInput == '1')
            {
                Console.WriteLine("You selected option '1'");
            }



        }

        public static void Loops()
        {
            int[] arr = new int[10] { 9, 1, 2, 3, 4, 5 ,6 ,8, 7, 0};


            foreach(int element in arr)
            {
                Console.WriteLine(element);
            }


            bool running = true;

            while (running)
            {
                Console.WriteLine("Enter 'N' to exit");
                string input = System.Console.ReadLine();


                if (input.StartsWith("N"))
                {
                    running = false;
                }
                //somewhere i must kill the program
            }

        }

        #endregion


        #region arrays and loops with arrays

        public static void arrays()
        {
            int[][] myINTarr = new int[10][];
            //var[][] myINTarr = new int[10][];

            int a = 4;
            var b = 4;
            //b = "bye"; //wont work as 'b' is an int
            var c = "Hello";

            //System.Console.WriteLine(mod1.Console.value);


            //looking at multiple arrays at same time of different types. say int[] and string[]
            //nested for loops
            //*
            //**
            //***
            //****

            string[] locations = new string[4] { "Seattle", "Tacoma", "Lakewood", "JBLM" };
            int[] rents = new int[4] { 3000, 2000, 1400, 0};

            for(int i = 0; i < locations.Length; i++)
            {
                Console.WriteLine(locations[i] + " rent is: " + rents[i]);
            }

            int[] printMe = new int[5] { 3, 5, 2, 7, 8 };

            for(int i = 0; i < printMe.Length; i++)
            {
                int target = printMe[i];
                for( int j = 0; j < target; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }

        public static void ForOrForeach()
        {
            //for
            //foreach
            //array
            //collection that cannot use for

            List<int> intList = new List<int>();
            Queue<int> intQ = new Queue<int>();

            intList.Add(5);
            intList.Add(5);
            intList.Add(2);
            intList.Add(5);
            intList.Add(47348);
            intList.Add(5);
            intList.Add(5343);
            intList.Add(3);
            intList.Add(5);
            intList.Add(90);
            intList.Add(5);

            intQ.Enqueue(7);
            intQ.Enqueue(17);
            intQ.Enqueue(7);
            intQ.Enqueue(77);
            intQ.Enqueue(7777);
            intQ.Enqueue(1);
            intQ.Enqueue(0);
            intQ.Enqueue(6);
            intQ.Enqueue(7);


            for (int i = 0; i < intList.Count; i++)
            {
                Console.WriteLine(intList[i]);
                //Console.WriteLine(); //for loop won't easily work with a Queue
                //for queue may need nested for to get to the elements
                //if removing item from list then i--;
            }

            foreach (int element in intList)
            {
                Console.WriteLine(element);
            }

            Console.WriteLine();

            foreach (int element in intList)
            {
                Console.WriteLine(element);
                //intList.Remove(element);
            }

            Console.WriteLine('\n');

            foreach(int element in intQ) //walks through the queue
            {
                Console.WriteLine(element);
                //element = 5; //wont let you do this
            }

            int yetAnotherint = intQ.Dequeue(); //removes and returns the first value

            Console.WriteLine('\n');

            foreach (int element in intQ)
            {
                Console.WriteLine(element);
            }
        }

        #endregion
    }

    //class Console
    //{
    //    public static int value = 9;
    //}
}
